package com.raylan.owerotmx.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

private val OwerDarkColorScheme = darkColorScheme(
  primary = NeonRed,
  onPrimary = Color.White,
  primaryContainer = NeonRedDark,
  onPrimaryContainer = Color.White,
  secondary = VipGold,
  onSecondary = BgDeepBlack,
  secondaryContainer = VipGoldSoft,
  onSecondaryContainer = VipGold,
  tertiary = TerminalGreen,
  onTertiary = BgDeepBlack,
  background = BgDeepBlack,
  onBackground = TextPrimary,
  surface = CardSurface,
  onSurface = TextPrimary,
  surfaceVariant = CardSurfaceElevated,
  onSurfaceVariant = TextSecondary,
  outline = CardBorderSubtle,
  error = NeonRed,
  onError = Color.White,
)

private val OwerShapes = Shapes(
  small = RoundedCornerShape(10.dp),
  medium = RoundedCornerShape(14.dp),
  large = RoundedCornerShape(18.dp),
)

@Composable
fun OwerOtmxTheme(content: @Composable () -> Unit) {
  MaterialTheme(
    colorScheme = OwerDarkColorScheme,
    typography = OwerTypography,
    shapes = OwerShapes,
    content = content,
  )
}
