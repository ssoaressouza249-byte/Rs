package com.raylan.owerotmx

import android.content.pm.PackageManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.raylan.owerotmx.shizuku.ShizukuExecutor
import com.raylan.owerotmx.ui.components.BottomActionDock
import com.raylan.owerotmx.ui.components.FpsModesSection
import com.raylan.owerotmx.ui.components.GameSelectorCard
import com.raylan.owerotmx.ui.components.HeaderSection
import com.raylan.owerotmx.ui.components.LiveTerminalSection
import com.raylan.owerotmx.ui.components.ShizukuAlertBanner
import com.raylan.owerotmx.ui.theme.BgDeepBlack
import com.raylan.owerotmx.ui.theme.NeonRed
import com.raylan.owerotmx.ui.theme.OwerOtmxTheme
import com.raylan.owerotmx.ui.theme.VipGold
import com.raylan.owerotmx.viewmodel.OwerViewModel
import rikka.shizuku.Shizuku

class MainActivity : ComponentActivity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge(
      statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
      navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
    )
    val isIntact = SecurityGuard.isAppIntact(this)
    setContent {
      OwerOtmxTheme {
        if (!isIntact) {
          SecurityTamperScreen()
        } else {
          OwerOtmxScreen()
        }
      }
    }
  }
}

@Composable
fun OwerOtmxScreen(viewModel: OwerViewModel = viewModel()) {
  val uiState by viewModel.uiState.collectAsStateWithLifecycle()
  val filteredApps by viewModel.filteredApps.collectAsStateWithLifecycle()

  DisposableEffect(Unit) {
    val binderReceivedListener = Shizuku.OnBinderReceivedListener {
      viewModel.onBinderReceived()
    }
    val binderDeadListener = Shizuku.OnBinderDeadListener {
      viewModel.onBinderDead()
    }
    val permissionResultListener = Shizuku.OnRequestPermissionResultListener { requestCode, grantResult ->
      viewModel.onPermissionResult(requestCode, grantResult)
    }

    runCatching {
      Shizuku.addBinderReceivedListenerSticky(binderReceivedListener)
      Shizuku.addBinderDeadListener(binderDeadListener)
      Shizuku.addRequestPermissionResultListener(permissionResultListener)
    }

    onDispose {
      runCatching {
        Shizuku.removeBinderReceivedListener(binderReceivedListener)
        Shizuku.removeBinderDeadListener(binderDeadListener)
        Shizuku.removeRequestPermissionResultListener(permissionResultListener)
      }
    }
  }

  LaunchedEffect(Unit) {
    runCatching {
      if (Shizuku.pingBinder()) {
        if (Shizuku.checkSelfPermission() != PackageManager.PERMISSION_GRANTED) {
          Shizuku.requestPermission(ShizukuExecutor.SHIZUKU_PERMISSION_REQUEST_CODE)
        }
      }
      viewModel.refreshShizukuStatus(autoRequestPermission = true)
    }
  }

  Scaffold(
    modifier = Modifier
      .fillMaxSize()
      .background(BgDeepBlack),
    containerColor = BgDeepBlack,
    contentWindowInsets = WindowInsets(0, 0, 0, 0),
    bottomBar = {
      BottomActionDock(
        selectedGame = uiState.selectedGame,
        selectedMode = uiState.selectedFpsMode,
        isApplying = uiState.isApplying,
        showLaunchGameButton = uiState.showLaunchGameButton,
        onActivateFps = viewModel::activateFps,
        onLaunchGame = viewModel::launchSelectedGame,
      )
    },
  ) { innerPadding ->
    Box(
      modifier = Modifier
        .fillMaxSize()
        .drawBehind {
          drawCircle(
            brush = Brush.radialGradient(
              colors = listOf(NeonRed.copy(alpha = 0.14f), Color.Transparent),
              center = Offset(size.width * 0.9f, size.height * 0.06f),
              radius = size.width * 0.8f,
            ),
            radius = size.width * 0.8f,
            center = Offset(size.width * 0.9f, size.height * 0.06f),
          )
          drawCircle(
            brush = Brush.radialGradient(
              colors = listOf(VipGold.copy(alpha = 0.07f), Color.Transparent),
              center = Offset(size.width * 0.1f, size.height * 0.48f),
              radius = size.width * 0.65f,
            ),
            radius = size.width * 0.65f,
            center = Offset(size.width * 0.1f, size.height * 0.48f),
          )
        }
        .padding(innerPadding)
        .windowInsetsPadding(WindowInsets.statusBars),
      contentAlignment = Alignment.TopCenter,
    ) {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .widthIn(max = 640.dp)
          .verticalScroll(rememberScrollState())
          .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
      ) {
        HeaderSection(
          shizukuStatus = uiState.shizukuStatus,
          isRestoring = uiState.isRestoring,
          onRestoreDefault = viewModel::restoreDefault,
          onStatusClick = { viewModel.refreshShizukuStatus(autoRequestPermission = true) },
        )

        ShizukuAlertBanner(
          shizukuStatus = uiState.shizukuStatus,
          onOpenShizuku = viewModel::openShizukuApp,
          onRequestPermission = viewModel::requestShizukuPermissionManually,
        )

        GameSelectorCard(
          apps = filteredApps,
          selectedGame = uiState.selectedGame,
          searchQuery = uiState.searchQuery,
          isLoading = uiState.isLoadingApps,
          onSearchQueryChange = viewModel::updateSearchQuery,
          onSelectGame = viewModel::selectGame,
          onRefreshApps = viewModel::loadInstalledApps,
        )

        FpsModesSection(
          selectedMode = uiState.selectedFpsMode,
          onSelectMode = viewModel::selectFpsMode,
        )

        LiveTerminalSection(
          logs = uiState.logs,
          onClearLogs = viewModel::clearLogs,
        )

        Spacer(modifier = Modifier.height(6.dp))
      }
    }
  }
}
